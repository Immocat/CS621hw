Zejian Wang
USC ID: 2302589089
CSCI 621
Ex 1
---------------------------------------------------------------------------------------
1.1 Installation and getting started

I build the OpenMesh and freeglut libraries on Linux. The freeglut is installed on my computer, so it's not in this .zip file. Please let me know if I should hand in them next time.

1.2 Vertex valence of a triangle mesh

Basically I follow the tutorial on OpenMesh's website (vertex iterator + circulator), and then I save each vertex's valence to a custom property "valence_" defined in ValenceViewer.hh. I also record the max and min valence for color visualization.

1.3 Color visualization
I defined 5 colors(Exercise1/colors.png), and the index of color for each vertex is "floor((current_valence-min_valance) * 4 / (max_valence-min_valence))"
