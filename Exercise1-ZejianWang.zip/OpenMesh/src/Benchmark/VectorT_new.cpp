/*
 * VectorT_new.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: ebke
 */

#include <benchmark/benchmark_api.h>
#include <OpenMesh/Core/Geometry/VectorT.hh>

#define BMPOSTFIX _CPP11
#include "VectorT.cpp"
